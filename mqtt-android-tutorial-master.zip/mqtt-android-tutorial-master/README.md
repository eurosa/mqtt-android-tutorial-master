# MQTT Android Service Tutorial
A tutorial for using the MQTT Android Service, as seen on https://wildanmsyah.wordpress.com/2017/05/11/mqtt-android-client-tutorial/

### Uses:
- Android Studio
- [Paho MQTT Android Service](https://github.com/eclipse/paho.mqtt.android)
- [CloudMQTT Broker](https://www.cloudmqtt.com/)
- [MPAndroidChart](https://github.com/PhilJay/MPAndroidChart)

